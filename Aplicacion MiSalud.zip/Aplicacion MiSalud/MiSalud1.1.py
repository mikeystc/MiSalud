import streamlit as st
import pandas as pd
from datetime import datetime, date, time
import random

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="MiSalud – Hospital de Primer Nivel",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Global CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&display=swap');
:root {
    --teal:   #0d9488; --teal2: #14b8a6; --navy:  #0f172a;
    --slate:  #1e293b; --card:  #1e293b; --border:#334155;
    --text:   #e2e8f0; --muted: #94a3b8; --accent:#f59e0b;
    --red:    #ef4444; --green: #22c55e; --blue:  #3b82f6;
}
html,body,[class*="css"]{ font-family:'DM Sans',sans-serif; background:var(--navy); color:var(--text); }
h1,h2,h3,h4,h5{ font-family:'Syne',sans-serif; }
section[data-testid="stSidebar"]{ background:var(--slate); border-right:1px solid var(--border); }
section[data-testid="stSidebar"] *{ color:var(--text) !important; }
.sec-header{ font-family:'Syne',sans-serif; font-size:1.4rem; font-weight:700; color:var(--teal2);
    border-left:4px solid var(--teal); padding-left:12px; margin-bottom:18px; }
.badge{ display:inline-block; padding:3px 10px; border-radius:999px; font-size:.75rem; font-weight:600; }
.badge-green { background:#16532440; color:#4ade80; border:1px solid #166534; }
.badge-yellow{ background:#78350f40; color:#fbbf24; border:1px solid #92400e; }
.badge-red   { background:#7f1d1d40; color:#f87171; border:1px solid #991b1b; }
.badge-blue  { background:#1e3a5f40; color:#60a5fa; border:1px solid #1e40af; }
.badge-purple{ background:#3b0f6040; color:#c084fc; border:1px solid #6b21a8; }
.badge-orange{ background:#7c2d1240; color:#fb923c; border:1px solid #9a3412; }
.urgency-card{ background:var(--card); border-left:4px solid var(--red);
    border-radius:0 10px 10px 0; padding:14px 18px; margin-bottom:10px; }
.urgency-card.mod{ border-color:var(--accent); }
.urgency-card.low{ border-color:var(--green); }
.record-card{ background:var(--card); border:1px solid var(--border); border-radius:12px;
    padding:16px 20px; margin-bottom:10px; }
.info-box{ background:#0d374240; border:1px solid var(--teal); border-radius:10px;
    padding:14px 18px; margin:10px 0; font-size:.9rem; }
div[data-testid="stMetric"]{ background:var(--card); border:1px solid var(--border);
    border-radius:12px; padding:16px; }
div[data-testid="stMetricLabel"] p{ color:var(--muted) !important; font-size:.82rem; }
div[data-testid="stMetricValue"] { color:var(--teal2) !important; font-family:'Syne',sans-serif; }
.stButton>button{ background:var(--teal); color:white; border:none; border-radius:8px;
    font-family:'DM Sans',sans-serif; font-weight:500; padding:8px 20px; transition:background .2s; }
.stButton>button:hover{ background:var(--teal2); }
.stTextInput>div>div>input,.stSelectbox>div>div,.stTextArea textarea{
    background:var(--slate) !important; border:1px solid var(--border) !important;
    color:var(--text) !important; border-radius:8px !important; }
hr{ border-color:var(--border); margin:24px 0; }
.dataframe{ background:var(--card) !important; }
thead tr th{ background:var(--slate) !important; color:var(--teal2) !important; }
.detail-panel{ background:#0f1f38; border:1px solid var(--teal); border-radius:14px; padding:24px 28px; margin-top:12px; }
.note-block{ background:#162032; border-left:3px solid var(--teal2); border-radius:0 8px 8px 0;
    padding:10px 14px; margin-bottom:8px; font-size:.88rem; }
</style>
""", unsafe_allow_html=True)


# ── Session state ─────────────────────────────────────────────────────────────
def init_state():
    defaults = {
        "pacientes": [
            {"id":"P-001","nombre":"Ana Gómez","edad":34,"sexo":"F","servicio":"Consulta Externa",
             "estado":"En espera","ingreso":datetime(2026,5,8,8,0),"medico":"Dr. Pérez","notas":[]},
            {"id":"P-002","nombre":"Carlos Ruiz","edad":67,"sexo":"M","servicio":"Urgencias",
             "estado":"En atención","ingreso":datetime(2026,5,8,7,30),"medico":"Dra. López","notas":[]},
            {"id":"P-003","nombre":"María Torres","edad":28,"sexo":"F","servicio":"Materno-Infantil",
             "estado":"En atención","ingreso":datetime(2026,5,8,6,0),"medico":"Dra. Mora","notas":[]},
            {"id":"P-004","nombre":"Juan Díaz","edad":45,"sexo":"M","servicio":"Hospitalización",
             "estado":"Estable","ingreso":datetime(2026,5,7,14,0),"medico":"Dr. Castillo","notas":[]},
            {"id":"P-005","nombre":"Lucía Vargas","edad":5,"sexo":"F","servicio":"Pediatría",
             "estado":"En espera","ingreso":datetime(2026,5,8,9,0),"medico":"Dra. Ríos","notas":[]},
        ],
        "citas": [
            {"id":"C-001","paciente":"Pedro Salcedo","fecha":date(2026,5,9),"hora":"09:00",
             "especialidad":"Medicina General","medico":"Dr. Pérez","estado":"Confirmada","notas":[]},
            {"id":"C-002","paciente":"Rosa Méndez","fecha":date(2026,5,9),"hora":"10:30",
             "especialidad":"Ginecología","medico":"Dra. Mora","estado":"Pendiente","notas":[]},
            {"id":"C-003","paciente":"Fabio León","fecha":date(2026,5,10),"hora":"08:00",
             "especialidad":"Pediatría","medico":"Dra. Ríos","estado":"Confirmada","notas":[]},
        ],
        "urgencias": [
            {"id":"URG-001","paciente":"Carlos Ruiz","triage":"Alto","motivo":"Dolor torácico",
             "estado":"En atención","llegada":datetime(2026,5,8,7,25),"notas":[]},
            {"id":"URG-002","paciente":"Sofía Castro","triage":"Moderado","motivo":"Fiebre 39 C",
             "estado":"En espera","llegada":datetime(2026,5,8,8,50),"notas":[]},
            {"id":"URG-003","paciente":"Tomás Herrera","triage":"Leve","motivo":"Herida superficial",
             "estado":"En espera","llegada":datetime(2026,5,8,9,10),"notas":[]},
        ],
        "inventario": [
            {"codigo":"MED-001","nombre":"Amoxicilina 500mg","categoria":"Antibiótico","stock":240,"minimo":50,"unidad":"Cápsulas"},
            {"codigo":"MED-002","nombre":"Ibuprofeno 400mg","categoria":"Analgésico","stock":18,"minimo":30,"unidad":"Tabletas"},
            {"codigo":"MED-003","nombre":"Metformina 850mg","categoria":"Antidiabético","stock":150,"minimo":40,"unidad":"Tabletas"},
            {"codigo":"MED-004","nombre":"Losartán 50mg","categoria":"Antihipertensivo","stock":0,"minimo":30,"unidad":"Tabletas"},
            {"codigo":"MED-005","nombre":"Acetaminofén 500mg","categoria":"Analgésico","stock":500,"minimo":100,"unidad":"Tabletas"},
            {"codigo":"INS-001","nombre":"Jeringas 5ml","categoria":"Insumo","stock":80,"minimo":50,"unidad":"Unidades"},
            {"codigo":"INS-002","nombre":"Guantes Látex M","categoria":"Insumo","stock":12,"minimo":100,"unidad":"Cajas"},
        ],
        "insumos_qx": [
            {"codigo":"QX-001","nombre":"Hoja de bisturí N10","categoria":"Corte","stock":150,"minimo":30,"unidad":"Unidades"},
            {"codigo":"QX-002","nombre":"Hoja de bisturí N22","categoria":"Corte","stock":90,"minimo":30,"unidad":"Unidades"},
            {"codigo":"QX-003","nombre":"Spongostan (hemostático)","categoria":"Hemostasia","stock":40,"minimo":10,"unidad":"Unidades"},
            {"codigo":"QX-004","nombre":"Sutura Vicryl 2-0","categoria":"Sutura","stock":60,"minimo":20,"unidad":"Sobres"},
            {"codigo":"QX-005","nombre":"Sutura Nylon 3-0","categoria":"Sutura","stock":45,"minimo":20,"unidad":"Sobres"},
            {"codigo":"QX-006","nombre":"Sutura Prolene 4-0","categoria":"Sutura","stock":8,"minimo":15,"unidad":"Sobres"},
            {"codigo":"QX-007","nombre":"Dren de Penrose","categoria":"Drenaje","stock":25,"minimo":10,"unidad":"Unidades"},
            {"codigo":"QX-008","nombre":"Compresas estériles","categoria":"Campo operatorio","stock":200,"minimo":50,"unidad":"Unidades"},
            {"codigo":"QX-009","nombre":"Electrobisturí (placa)","categoria":"Electrocirugía","stock":20,"minimo":5,"unidad":"Unidades"},
            {"codigo":"QX-010","nombre":"Catéter Foley 18Fr","categoria":"Sondaje","stock":30,"minimo":10,"unidad":"Unidades"},
            {"codigo":"QX-011","nombre":"Gasas estériles 10x10","categoria":"Campo operatorio","stock":0,"minimo":100,"unidad":"Paquetes"},
            {"codigo":"QX-012","nombre":"Agujas de Veress","categoria":"Laparoscopía","stock":6,"minimo":5,"unidad":"Unidades"},
            {"codigo":"QX-013","nombre":"Trocar 5mm","categoria":"Laparoscopía","stock":4,"minimo":3,"unidad":"Unidades"},
            {"codigo":"QX-014","nombre":"Esponja de celulosa","categoria":"Hemostasia","stock":35,"minimo":10,"unidad":"Unidades"},
            {"codigo":"QX-015","nombre":"Campo operatorio estéril","categoria":"Campo operatorio","stock":50,"minimo":20,"unidad":"Unidades"},
        ],
        "cirugias": [
            {"id":"CIR-001","paciente":"Juan Díaz","doctor":"Dr. Castillo","tipo":"Apendicectomía",
             "fecha":date(2026,5,10),"hora":"08:00","sala":"Quirófano 1","estado":"Programada",
             "notas":[],"insumos_usados":[]},
            {"id":"CIR-002","paciente":"Ana Gómez","doctor":"Dra. Mora","tipo":"Cesárea",
             "fecha":date(2026,5,8),"hora":"14:00","sala":"Quirófano 2","estado":"En curso",
             "notas":[],"insumos_usados":[]},
        ],
        "laboratorio": [
            {"id":"LAB-001","paciente":"Carlos Ruiz","examen":"Hemograma completo","estado":"Listo",
             "fecha":datetime(2026,5,8,7,45),"resultado":"Hb 11.2 g/dL - Leucocitos 11000","notas":[]},
            {"id":"LAB-002","paciente":"Ana Gómez","examen":"Química sanguínea","estado":"En proceso",
             "fecha":datetime(2026,5,8,8,10),"resultado":"—","notas":[]},
            {"id":"LAB-003","paciente":"Lucía Vargas","examen":"Uroanálisis","estado":"Pendiente",
             "fecha":datetime(2026,5,8,9,5),"resultado":"—","notas":[]},
        ],
        "camas": {f"C-{i:02d}": ("Ocupada" if i in [1,3,5,7,10] else "Libre") for i in range(1,21)},
        "vacunacion": [
            {"paciente":"Lucía Vargas (5a)","vacuna":"Polio","dosis":"3a","fecha":date(2026,5,8),"lote":"LOT-2245","enfermera":"Enf. Díaz"},
            {"paciente":"Samuel Mora (2m)","vacuna":"BCG","dosis":"1a","fecha":date(2026,5,8),"lote":"LOT-1198","enfermera":"Enf. Soto"},
        ],
        "personal": [
            {"nombre":"Dr. Pérez","cargo":"Médico General","turno":"Mañana","estado":"Activo"},
            {"nombre":"Dra. López","cargo":"Médico Urgencias","turno":"Mañana","estado":"Activo"},
            {"nombre":"Dra. Mora","cargo":"Ginecóloga","turno":"Mañana","estado":"Activo"},
            {"nombre":"Dr. Castillo","cargo":"Médico General","turno":"Tarde","estado":"Activo"},
            {"nombre":"Dra. Ríos","cargo":"Pediatra","turno":"Mañana","estado":"Activo"},
            {"nombre":"Enf. Díaz","cargo":"Enfermera Profesional","turno":"Mañana","estado":"Activo"},
            {"nombre":"Enf. Soto","cargo":"Auxiliar Enfermería","turno":"Mañana","estado":"Activo"},
        ],
        "epidemiologia": [
            {"semana":"2026-W17","enfermedad":"IRA","casos":23,"alerta":False},
            {"semana":"2026-W17","enfermedad":"EDA","casos":11,"alerta":False},
            {"semana":"2026-W17","enfermedad":"Dengue","casos":4,"alerta":True},
            {"semana":"2026-W18","enfermedad":"IRA","casos":31,"alerta":True},
        ],
        "telemedicina": [
            {"id":"TM-001","paciente":"Ernesto Gil","especialista":"Cardiólogo - HUV",
             "fecha":datetime(2026,5,9,10,0),"estado":"Programada","notas":[]},
            {"id":"TM-002","paciente":"Paula Vega","especialista":"Dermatólogo - Clínica Norte",
             "fecha":datetime(2026,5,8,11,0),"estado":"En curso","notas":[]},
        ],
        # UI navigation state
        "detalle_urg":       None,
        "detalle_cita":      None,
        "detalle_cirugia":   None,
        "cirugia_insumos_id":None,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

init_state()

# ── Helpers ───────────────────────────────────────────────────────────────────
def badge(text, color="green"):
    return f'<span class="badge badge-{color}">{text}</span>'

def sec(title):
    st.markdown(f'<div class="sec-header">{title}</div>', unsafe_allow_html=True)

def render_notas(notas):
    if notas:
        st.markdown("**Notas del médico:**")
        for n in notas:
            st.markdown(
                f'<div class="note-block">🩺 <b>{n["autor"]}</b> — '
                f'<span style="color:#94a3b8">{n["fecha"]}</span><br>{n["texto"]}</div>',
                unsafe_allow_html=True)
    else:
        st.markdown('<p style="color:#94a3b8;font-size:.85rem">Sin notas registradas.</p>', unsafe_allow_html=True)

def agregar_nota(registro, texto, autor):
    if texto and texto.strip():
        registro.setdefault("notas", []).append({
            "texto": texto.strip(),
            "autor": autor,
            "fecha": datetime.now().strftime("%d/%m/%Y %H:%M")
        })

# ── Estados por módulo (distintos entre sí) ───────────────────────────────────
ESTADOS_URGENCIAS    = ["En espera","En atención","Observación","Para traslado","Alta médica","Alta voluntaria"]
ESTADOS_CONSULTA     = ["Pendiente","Confirmada","En consulta","Atendida","Cancelada","No asistió"]
ESTADOS_HOSP         = ["En espera cama","Hospitalizado","Estable","En observación","Pre-alta","Alta"]
ESTADOS_MAT          = ["En espera","En atención","En trabajo de parto","Post-parto","Alta"]
ESTADOS_CIRUGIA      = ["Programada","En curso","Finalizada","Suspendida","Cancelada"]
ESTADOS_LAB          = ["Pendiente","En proceso","Listo"]
ESTADOS_TELEMEDICINA = ["Programada","En curso","Finalizada","Cancelada"]

NOMBRES_MEDICOS = lambda: [p["nombre"] for p in st.session_state.personal]

# ─────────────────────────────────────────────────────────────────────────────
# SIDEBAR
# ─────────────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="text-align:center;padding:16px 0 24px">
      <div style="font-family:'Syne',sans-serif;font-size:1.8rem;font-weight:800;color:#14b8a6">🏥 MiSalud</div>
      <div style="font-size:.78rem;color:#94a3b8;margin-top:2px">Hospital de Primer Nivel</div>
    </div>""", unsafe_allow_html=True)

    modulo = st.radio("Módulo", [
        "🏠 Dashboard",
        "🚨 Urgencias",
        "📅 Consulta Externa",
        "🛏️ Hospitalización",
        "👶 Materno-Infantil",
        "🔬 Laboratorio",
        "💊 Farmacia",
        "🧰 Insumos Quirúrgicos",
        "🏥 Cirugías",
        "🌐 Telemedicina",
        "📊 Epidemiología",
        "👤 Personal",
    ], label_visibility="collapsed")

    st.markdown("---")
    st.markdown(f'<div style="font-size:.78rem;color:#94a3b8;text-align:center">{datetime.now().strftime("%d/%m/%Y  %H:%M")}</div>', unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════════════════
# 1. DASHBOARD
# ═══════════════════════════════════════════════════════════════════════════════
if modulo == "🏠 Dashboard":
    st.markdown("<h1 style='margin-bottom:4px'>Panel General</h1>", unsafe_allow_html=True)
    st.markdown('<p style="color:#94a3b8;margin-bottom:28px">Resumen operativo en tiempo real</p>', unsafe_allow_html=True)

    camas_ocu = sum(1 for v in st.session_state.camas.values() if v == "Ocupada")
    pac_hoy   = len(st.session_state.pacientes)
    urg_act   = sum(1 for u in st.session_state.urgencias if u["estado"] not in ["Alta médica","Alta voluntaria"])
    labs_pend = sum(1 for l in st.session_state.laboratorio if l["estado"] != "Listo")
    cir_hoy   = sum(1 for c in st.session_state.cirugias if c["estado"] in ["Programada","En curso"])
    med_bajo  = sum(1 for m in st.session_state.inventario if m["stock"] <= m["minimo"])

    cols = st.columns(6)
    cols[0].metric("Pacientes hoy",     pac_hoy)
    cols[1].metric("Camas ocupadas",    f"{camas_ocu}/20")
    cols[2].metric("Urgencias activas", urg_act)
    cols[3].metric("Labs pendientes",   labs_pend)
    cols[4].metric("Cirugías hoy",      cir_hoy)
    cols[5].metric("Alertas farmacia",  med_bajo, delta_color="inverse")

    st.markdown("<br>", unsafe_allow_html=True)
    col_a, col_b = st.columns([3,2])
    with col_a:
        sec("Pacientes activos")
        df = pd.DataFrame(st.session_state.pacientes)
        df["ingreso"] = df["ingreso"].apply(lambda x: x.strftime("%H:%M"))
        st.dataframe(df[["id","nombre","edad","servicio","estado","medico","ingreso"]].rename(columns={
            "id":"ID","nombre":"Nombre","edad":"Edad","servicio":"Servicio",
            "estado":"Estado","medico":"Médico","ingreso":"Ingreso"}),
            use_container_width=True, hide_index=True)
    with col_b:
        sec("Estado de camas")
        filas = []
        for cama, est in st.session_state.camas.items():
            color = "#ef444420" if est=="Ocupada" else "#22c55e20"
            borde = "#ef4444"   if est=="Ocupada" else "#22c55e"
            icono = "🔴" if est=="Ocupada" else "🟢"
            filas.append(f'<div style="display:inline-block;margin:4px;padding:6px 10px;border:1px solid {borde};border-radius:8px;background:{color};font-size:.78rem">{icono} {cama}</div>')
        st.markdown("".join(filas), unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    col_e, col_f = st.columns(2)
    with col_e:
        sec("Alertas epidemiológicas")
        for row in st.session_state.epidemiologia:
            if row["alerta"]:
                st.markdown(f'<div class="info-box">⚠️ <b>{row["enfermedad"]}</b> — {row["casos"]} casos — Semana {row["semana"]}</div>', unsafe_allow_html=True)
    with col_f:
        sec("Cirugías del día")
        for cir in st.session_state.cirugias:
            if cir["estado"] in ["Programada","En curso"]:
                col_bc = "blue" if cir["estado"]=="Programada" else "green"
                st.markdown(f'<div class="info-box">🔪 <b>{cir["tipo"]}</b> — {cir["paciente"]} — {cir["hora"]} {badge(cir["estado"],col_bc)}</div>', unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════════════════════════
# 2. URGENCIAS
# ═══════════════════════════════════════════════════════════════════════════════
elif modulo == "🚨 Urgencias":
    st.markdown("<h1>Urgencias Básicas 24/7</h1>", unsafe_allow_html=True)
    st.markdown('<p style="color:#94a3b8;margin-bottom:20px">Atención de casos leves, moderados y estabilización para traslado</p>', unsafe_allow_html=True)

    if st.session_state.detalle_urg is not None:
        idx = st.session_state.detalle_urg
        u   = st.session_state.urgencias[idx]
        if st.button("← Volver a la lista"):
            st.session_state.detalle_urg = None
            st.rerun()

        st.markdown(f"<h2>Urgencia {u['id']}</h2>", unsafe_allow_html=True)
        st.markdown('<div class="detail-panel">', unsafe_allow_html=True)
        c1,c2 = st.columns(2)
        c1.markdown(f"**Paciente:** {u['paciente']}")
        c1.markdown(f"**Llegada:** {u['llegada'].strftime('%d/%m/%Y %H:%M')}")
        c2.markdown(f"**Triage:** {u['triage']}")
        c2.markdown(f"**Motivo:** {u['motivo']}")
        st.markdown("---")
        with st.form("edit_urg"):
            c1,c2,c3 = st.columns(3)
            nuevo_estado = c1.selectbox("Estado", ESTADOS_URGENCIAS,
                                         index=ESTADOS_URGENCIAS.index(u["estado"]) if u["estado"] in ESTADOS_URGENCIAS else 0)
            nuevo_triage = c2.selectbox("Triage", ["Alto","Moderado","Leve"],
                                         index=["Alto","Moderado","Leve"].index(u["triage"]))
            nuevo_motivo = c3.text_input("Motivo", value=u["motivo"])
            nota_txt = st.text_area("Agregar nota médica", height=80,
                                     placeholder="Evolución clínica, indicaciones, observaciones...")
            autor = st.selectbox("Médico que registra", NOMBRES_MEDICOS())
            if st.form_submit_button("💾 Guardar cambios"):
                u["estado"] = nuevo_estado
                u["triage"] = nuevo_triage
                u["motivo"] = nuevo_motivo
                agregar_nota(u, nota_txt, autor)
                st.success("✅ Urgencia actualizada.")
                st.rerun()
        st.markdown("---")
        render_notas(u.get("notas",[]))
        st.markdown('</div>', unsafe_allow_html=True)

    else:
        sec("Cola de urgencias — presiona ✏️ para ver detalle")
        for idx, u in enumerate(st.session_state.urgencias):
            triage_css = {"Alto":"urgency-card","Moderado":"urgency-card mod","Leve":"urgency-card low"}[u["triage"]]
            badge_col  = {"Alto":"red","Moderado":"yellow","Leve":"green"}[u["triage"]]
            est_col    = {"En espera":"yellow","En atención":"blue","Observación":"purple",
                          "Para traslado":"orange","Alta médica":"green","Alta voluntaria":"green"}.get(u["estado"],"blue")
            col_card, col_btn = st.columns([9,1])
            with col_card:
                st.markdown(f"""
                <div class="{triage_css}">
                  <b>{u['id']} — {u['paciente']}</b>
                  &nbsp;{badge(u['triage'],badge_col)}&nbsp;{badge(u['estado'],est_col)}
                  <br><span style="color:#94a3b8;font-size:.85rem">🕐 {u['llegada'].strftime('%H:%M')} | {u['motivo']}</span>
                </div>""", unsafe_allow_html=True)
            with col_btn:
                st.markdown("<br>", unsafe_allow_html=True)
                if st.button("✏️", key=f"urg_edit_{idx}"):
                    st.session_state.detalle_urg = idx
                    st.rerun()

        st.markdown("<br>", unsafe_allow_html=True)
        sec("Registrar nueva urgencia")
        with st.form("form_urg", clear_on_submit=True):
            c1,c2  = st.columns(2)
            nombre = c1.text_input("Nombre del paciente")
            triage = c2.selectbox("Triage", ["Alto","Moderado","Leve"])
            motivo = st.text_input("Motivo de consulta")
            if st.form_submit_button("Registrar urgencia") and nombre:
                nuevo_id = f"URG-{len(st.session_state.urgencias)+1:03d}"
                st.session_state.urgencias.append({
                    "id":nuevo_id,"paciente":nombre,"triage":triage,
                    "motivo":motivo,"estado":"En espera","llegada":datetime.now(),"notas":[]
                })
                st.success(f"✅ Urgencia {nuevo_id} registrada.")
                st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# 3. CONSULTA EXTERNA
# ═══════════════════════════════════════════════════════════════════════════════
elif modulo == "📅 Consulta Externa":
    st.markdown("<h1>Consulta Externa General</h1>", unsafe_allow_html=True)
    st.markdown('<p style="color:#94a3b8;margin-bottom:20px">Medicina general · Pediatría · Ginecología · Programas PyM</p>', unsafe_allow_html=True)

    if st.session_state.detalle_cita is not None:
        idx = st.session_state.detalle_cita
        c   = st.session_state.citas[idx]
        if st.button("← Volver a la lista"):
            st.session_state.detalle_cita = None
            st.rerun()

        st.markdown(f"<h2>Cita {c['id']}</h2>", unsafe_allow_html=True)
        st.markdown('<div class="detail-panel">', unsafe_allow_html=True)
        c1,c2 = st.columns(2)
        c1.markdown(f"**Paciente:** {c['paciente']}")
        c1.markdown(f"**Especialidad:** {c['especialidad']}")
        c2.markdown(f"**Médico:** {c['medico']}")
        c2.markdown(f"**Fecha/Hora:** {c['fecha']} — {c['hora']}")
        st.markdown("---")
        with st.form("edit_cita"):
            horas = ["08:00","09:00","10:00","10:30","11:00","14:00","15:00","16:00"]
            c1,c2 = st.columns(2)
            nuevo_estado = c1.selectbox("Estado", ESTADOS_CONSULTA,
                                         index=ESTADOS_CONSULTA.index(c["estado"]) if c["estado"] in ESTADOS_CONSULTA else 0)
            nueva_hora   = c2.selectbox("Hora", horas,
                                         index=horas.index(c["hora"]) if c["hora"] in horas else 0)
            nueva_fecha  = st.date_input("Fecha", value=c["fecha"])
            nota_txt = st.text_area("Nota médica / diagnóstico", height=80,
                                     placeholder="Diagnóstico, tratamiento, indicaciones de seguimiento...")
            autor = st.selectbox("Médico que registra", NOMBRES_MEDICOS())
            if st.form_submit_button("💾 Guardar cambios"):
                c["estado"] = nuevo_estado
                c["hora"]   = nueva_hora
                c["fecha"]  = nueva_fecha
                agregar_nota(c, nota_txt, autor)
                st.success("✅ Cita actualizada.")
                st.rerun()
        st.markdown("---")
        render_notas(c.get("notas",[]))
        st.markdown('</div>', unsafe_allow_html=True)

    else:
        sec("Citas programadas — presiona ✏️ para ver y editar")
        for idx, c in enumerate(st.session_state.citas):
            est_col = {"Pendiente":"yellow","Confirmada":"blue","En consulta":"purple",
                       "Atendida":"green","Cancelada":"red","No asistió":"red"}.get(c["estado"],"blue")
            col_card, col_btn = st.columns([9,1])
            with col_card:
                st.markdown(f"""
                <div class="record-card">
                  <b>{c['id']} — {c['paciente']}</b> &nbsp;{badge(c['estado'],est_col)}
                  <br><span style="color:#94a3b8;font-size:.85rem">
                    📅 {c['fecha']} {c['hora']} | {c['especialidad']} | {c['medico']}
                  </span>
                </div>""", unsafe_allow_html=True)
            with col_btn:
                st.markdown("<br>", unsafe_allow_html=True)
                if st.button("✏️", key=f"cita_edit_{idx}"):
                    st.session_state.detalle_cita = idx
                    st.rerun()

        st.markdown("<br>", unsafe_allow_html=True)
        sec("Agendar nueva cita")
        with st.form("form_cita", clear_on_submit=True):
            c1,c2,c3 = st.columns(3)
            nombre = c1.text_input("Nombre del paciente")
            espec  = c2.selectbox("Especialidad", ["Medicina General","Pediatría","Ginecología","Odontología","Promoción y Mantenimiento"])
            medico = c3.selectbox("Médico", [p["nombre"] for p in st.session_state.personal
                                              if any(x in p["cargo"] for x in ["Médico","Pediatra","Ginecó","Odontó"])])
            c4,c5 = st.columns(2)
            fecha = c4.date_input("Fecha", min_value=date.today())
            hora  = c5.selectbox("Hora", ["08:00","09:00","10:00","10:30","11:00","14:00","15:00","16:00"])
            if st.form_submit_button("Agendar cita") and nombre:
                nuevo_id = f"C-{len(st.session_state.citas)+1:03d}"
                st.session_state.citas.append({
                    "id":nuevo_id,"paciente":nombre,"fecha":fecha,"hora":hora,
                    "especialidad":espec,"medico":medico,"estado":"Pendiente","notas":[]
                })
                st.success(f"✅ Cita {nuevo_id} agendada.")
                st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# 4. HOSPITALIZACIÓN
# ═══════════════════════════════════════════════════════════════════════════════
elif modulo == "🛏️ Hospitalización":
    st.markdown("<h1>Hospitalización Corta Estancia</h1>", unsafe_allow_html=True)
    ocu = sum(1 for v in st.session_state.camas.values() if v=="Ocupada")
    c1,c2,c3 = st.columns(3)
    c1.metric("Camas totales",20); c2.metric("Ocupadas",ocu); c3.metric("Disponibles",20-ocu)

    st.markdown("<br>", unsafe_allow_html=True)
    hosp = [p for p in st.session_state.pacientes if p["servicio"]=="Hospitalización"]
    if hosp:
        sec("Pacientes hospitalizados — presiona ✏️ para editar")
        for p in hosp:
            ig = st.session_state.pacientes.index(p)
            est_col = {"En espera cama":"yellow","Hospitalizado":"blue","Estable":"green",
                       "En observación":"purple","Pre-alta":"orange","Alta":"green"}.get(p["estado"],"blue")
            col_card, col_btn = st.columns([9,1])
            with col_card:
                st.markdown(f"""
                <div class="record-card">
                  <b>{p['id']} — {p['nombre']}</b> &nbsp;{badge(p['estado'],est_col)}
                  <br><span style="color:#94a3b8;font-size:.85rem">👨‍⚕️ {p['medico']} | Ingreso: {p['ingreso'].strftime('%d/%m %H:%M')}</span>
                </div>""", unsafe_allow_html=True)
            with col_btn:
                st.markdown("<br>", unsafe_allow_html=True)
                if st.button("✏️", key=f"hosp_edit_{ig}"):
                    st.session_state[f"hosp_open_{ig}"] = not st.session_state.get(f"hosp_open_{ig}",False)
                    st.rerun()
            if st.session_state.get(f"hosp_open_{ig}",False):
                with st.form(f"edit_hosp_{ig}"):
                    nuevo_estado = st.selectbox("Estado", ESTADOS_HOSP,
                        index=ESTADOS_HOSP.index(p["estado"]) if p["estado"] in ESTADOS_HOSP else 0)
                    nuevo_medico = st.selectbox("Médico tratante",
                        [m["nombre"] for m in st.session_state.personal if "Médico" in m["cargo"]])
                    nota_txt = st.text_area("Nota médica", height=70)
                    autor    = st.selectbox("Médico que registra", NOMBRES_MEDICOS())
                    if st.form_submit_button("💾 Guardar"):
                        st.session_state.pacientes[ig]["estado"] = nuevo_estado
                        st.session_state.pacientes[ig]["medico"] = nuevo_medico
                        agregar_nota(st.session_state.pacientes[ig], nota_txt, autor)
                        st.session_state[f"hosp_open_{ig}"] = False
                        st.success("✅ Actualizado.")
                        st.rerun()
                render_notas(p.get("notas",[]))

    st.markdown("<br>", unsafe_allow_html=True)
    sec("Mapa de camas")
    cols = st.columns(5)
    for idx,(cama,est) in enumerate(st.session_state.camas.items()):
        color = "#ef4444" if est=="Ocupada" else "#22c55e"
        with cols[idx%5]:
            st.markdown(f"""
            <div style="border:1px solid {color};border-radius:10px;padding:12px;text-align:center;background:{color}15;margin-bottom:8px">
              <div style="font-size:1.4rem">{"🛏️" if est=="Ocupada" else "✅"}</div>
              <div style="font-family:'Syne',sans-serif;font-size:.85rem;font-weight:700">{cama}</div>
              <div style="font-size:.72rem;color:{color}">{est}</div>
            </div>""", unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    sec("Gestionar cama")
    with st.form("form_cama"):
        c1,c2 = st.columns(2)
        cama_sel = c1.selectbox("Cama", list(st.session_state.camas.keys()))
        accion   = c2.selectbox("Acción", ["Ocupar","Liberar"])
        if st.form_submit_button("Actualizar"):
            st.session_state.camas[cama_sel] = "Ocupada" if accion=="Ocupar" else "Libre"
            st.success(f"✅ Cama {cama_sel} → {st.session_state.camas[cama_sel]}.")
            st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# 5. MATERNO-INFANTIL
# ═══════════════════════════════════════════════════════════════════════════════
elif modulo == "👶 Materno-Infantil":
    st.markdown("<h1>Atención Materno-Infantil</h1>", unsafe_allow_html=True)
    tab1, tab2 = st.tabs(["🤰 Sala de Partos", "💉 Vacunación"])

    with tab1:
        gestantes = [p for p in st.session_state.pacientes if p["servicio"]=="Materno-Infantil"]
        sec("Gestantes activas — presiona ✏️ para editar")
        if gestantes:
            for p in gestantes:
                ig = st.session_state.pacientes.index(p)
                est_col = {"En atención":"blue","Estable":"green","Alta":"green",
                           "En espera":"yellow","En trabajo de parto":"purple","Post-parto":"orange"}.get(p["estado"],"blue")
                col_card, col_btn = st.columns([9,1])
                with col_card:
                    st.markdown(f"""
                    <div class="record-card">
                      <b>{p['id']} — {p['nombre']}</b> &nbsp;{badge(p['estado'],est_col)}
                      <br><span style="color:#94a3b8;font-size:.85rem">👩‍⚕️ {p['medico']}</span>
                    </div>""", unsafe_allow_html=True)
                with col_btn:
                    st.markdown("<br>", unsafe_allow_html=True)
                    if st.button("✏️", key=f"mat_edit_{ig}"):
                        st.session_state[f"mat_open_{ig}"] = not st.session_state.get(f"mat_open_{ig}",False)
                        st.rerun()
                if st.session_state.get(f"mat_open_{ig}",False):
                    with st.form(f"edit_mat_{ig}"):
                        nuevo_estado = st.selectbox("Estado", ESTADOS_MAT,
                            index=ESTADOS_MAT.index(p["estado"]) if p["estado"] in ESTADOS_MAT else 0)
                        nota_txt = st.text_area("Nota médica / partograma", height=70)
                        autor    = st.selectbox("Responsable", NOMBRES_MEDICOS())
                        if st.form_submit_button("💾 Guardar"):
                            st.session_state.pacientes[ig]["estado"] = nuevo_estado
                            agregar_nota(st.session_state.pacientes[ig], nota_txt, autor)
                            st.session_state[f"mat_open_{ig}"] = False
                            st.rerun()
                    render_notas(p.get("notas",[]))
        else:
            st.info("Sin gestantes activas.")

        st.markdown("<br>", unsafe_allow_html=True)
        sec("Registrar ingreso gestante")
        with st.form("form_gestante", clear_on_submit=True):
            c1,c2    = st.columns(2)
            nombre_g = c1.text_input("Nombre")
            edad_g   = c2.number_input("Edad",14,60,25)
            semanas  = st.slider("Semanas de gestación",20,42,38)
            riesgo   = st.selectbox("Riesgo",["Bajo riesgo","Riesgo moderado"])
            if st.form_submit_button("Registrar") and nombre_g:
                st.session_state.pacientes.append({
                    "id":f"P-{len(st.session_state.pacientes)+1:03d}",
                    "nombre":nombre_g,"edad":edad_g,"sexo":"F",
                    "servicio":"Materno-Infantil","estado":"En espera",
                    "ingreso":datetime.now(),"medico":"Dra. Mora","semanas":semanas,"riesgo":riesgo,"notas":[]
                })
                st.success("✅ Gestante registrada.")
                st.rerun()

    with tab2:
        sec("Registro de vacunación")
        df_vac = pd.DataFrame(st.session_state.vacunacion)
        df_vac["fecha"] = df_vac["fecha"].apply(str)
        st.dataframe(df_vac, use_container_width=True, hide_index=True)
        with st.form("form_vac", clear_on_submit=True):
            c1,c2,c3 = st.columns(3)
            pac_v  = c1.text_input("Paciente")
            vacuna = c2.selectbox("Vacuna",["BCG","Polio","Triple viral","Hepatitis B","Pentavalente","Varicela","DPT","Influenza"])
            dosis  = c3.selectbox("Dosis",["1a","2a","3a","Refuerzo"])
            c4,c5  = st.columns(2)
            lote   = c4.text_input("Lote", f"LOT-{random.randint(1000,9999)}")
            enfer  = c5.selectbox("Enfermera",[p["nombre"] for p in st.session_state.personal if "Enferm" in p["cargo"] or "Auxiliar" in p["cargo"]])
            if st.form_submit_button("Registrar") and pac_v:
                st.session_state.vacunacion.append({"paciente":pac_v,"vacuna":vacuna,"dosis":dosis,"fecha":date.today(),"lote":lote,"enfermera":enfer})
                st.success("✅ Vacunación registrada.")
                st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# 6. LABORATORIO
# ═══════════════════════════════════════════════════════════════════════════════
elif modulo == "🔬 Laboratorio":
    st.markdown("<h1>Laboratorio Clínico Básico</h1>", unsafe_allow_html=True)

    sec("Órdenes — presiona ✏️ para actualizar resultado")
    for idx, lab in enumerate(st.session_state.laboratorio):
        col_badge = {"Listo":"green","En proceso":"blue","Pendiente":"yellow"}[lab["estado"]]
        icono     = {"Listo":"✅","En proceso":"⚙️","Pendiente":"🕐"}[lab["estado"]]
        col_card, col_btn = st.columns([9,1])
        with col_card:
            st.markdown(f"""
            <div class="record-card">
              <b>{lab['id']}</b> — {lab['paciente']} — <i>{lab['examen']}</i>
              &nbsp;{badge(f"{icono} {lab['estado']}",col_badge)}
              <br><span style="color:#94a3b8;font-size:.82rem">Resultado: {lab['resultado']}</span>
            </div>""", unsafe_allow_html=True)
        with col_btn:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("✏️", key=f"lab_edit_{idx}"):
                st.session_state[f"lab_open_{idx}"] = not st.session_state.get(f"lab_open_{idx}",False)
                st.rerun()
        if st.session_state.get(f"lab_open_{idx}",False):
            with st.form(f"edit_lab_{idx}"):
                nuevo_estado = st.selectbox("Estado", ESTADOS_LAB, index=ESTADOS_LAB.index(lab["estado"]))
                nuevo_res    = st.text_input("Resultado", value=lab["resultado"])
                nota_txt     = st.text_area("Observación técnica", height=60)
                autor        = st.selectbox("Responsable", NOMBRES_MEDICOS())
                if st.form_submit_button("💾 Guardar"):
                    lab["estado"]    = nuevo_estado
                    lab["resultado"] = nuevo_res
                    agregar_nota(lab, nota_txt, autor)
                    st.session_state[f"lab_open_{idx}"] = False
                    st.rerun()
            render_notas(lab.get("notas",[]))

    st.markdown("<br>", unsafe_allow_html=True)
    sec("Solicitar examen")
    with st.form("form_lab", clear_on_submit=True):
        c1,c2 = st.columns(2)
        pac_l = c1.text_input("Paciente")
        exam  = c2.selectbox("Examen",["Hemograma completo","Química sanguínea básica","Uroanálisis",
            "Coprológico","Glicemia","Creatinina","Perfil lipídico","Rayos X tórax","Rayos X extremidades","Prueba embarazo"])
        if st.form_submit_button("Solicitar examen") and pac_l:
            nuevo_id = f"LAB-{len(st.session_state.laboratorio)+1:03d}"
            st.session_state.laboratorio.append({"id":nuevo_id,"paciente":pac_l,"examen":exam,
                "estado":"Pendiente","fecha":datetime.now(),"resultado":"—","notas":[]})
            st.success(f"✅ {nuevo_id} solicitado.")
            st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# 7. FARMACIA
# ═══════════════════════════════════════════════════════════════════════════════
elif modulo == "💊 Farmacia":
    st.markdown("<h1>Farmacia e Insumos PBS</h1>", unsafe_allow_html=True)

    bajo = [m for m in st.session_state.inventario if 0 < m["stock"] <= m["minimo"]]
    agot = [m for m in st.session_state.inventario if m["stock"]==0]
    c1,c2,c3 = st.columns(3)
    c1.metric("Ítems",len(st.session_state.inventario))
    c2.metric("Stock bajo",len(bajo),delta_color="inverse")
    c3.metric("Agotados",len(agot),delta_color="inverse")

    st.markdown("<br>", unsafe_allow_html=True)
    sec("Inventario PBS")
    rows = ""
    for m in st.session_state.inventario:
        pct = min(100, int(m["stock"]/max(m["minimo"]*2,1)*100))
        color,label = ("#ef4444","Agotado") if m["stock"]==0 else \
                      (("#f59e0b","Stock bajo") if m["stock"]<=m["minimo"] else ("#22c55e","OK"))
        rows += f"""
        <div style="background:#1e293b;border:1px solid #334155;border-radius:10px;padding:14px 18px;margin-bottom:8px">
          <div style="display:flex;justify-content:space-between">
            <div><b>{m['nombre']}</b> <span style="color:#94a3b8;font-size:.8rem">({m['categoria']})</span></div>
            <div style="color:{color};font-weight:600">{m['stock']} {m['unidad']} — {label}</div>
          </div>
          <div style="background:#0f172a;border-radius:4px;height:6px;margin-top:8px">
            <div style="background:{color};width:{pct}%;height:6px;border-radius:4px"></div>
          </div>
          <div style="color:#94a3b8;font-size:.75rem;margin-top:4px">Mínimo: {m['minimo']} · {m['codigo']}</div>
        </div>"""
    st.markdown(rows, unsafe_allow_html=True)

    col_d,col_e = st.columns(2)
    with col_d:
        sec("Dispensar")
        with st.form("form_disp", clear_on_submit=True):
            item  = st.selectbox("Medicamento",[m["nombre"] for m in st.session_state.inventario if m["stock"]>0])
            cant  = st.number_input("Cantidad",1,100,1)
            pac_f = st.text_input("Paciente")
            if st.form_submit_button("Dispensar") and pac_f:
                for m in st.session_state.inventario:
                    if m["nombre"]==item:
                        if m["stock"]>=cant: m["stock"]-=cant; st.success("✅ Dispensado.")
                        else: st.error("Stock insuficiente.")
                st.rerun()
    with col_e:
        sec("Reponer stock")
        with st.form("form_repo", clear_on_submit=True):
            item_r = st.selectbox("Ítem",[m["nombre"] for m in st.session_state.inventario])
            cant_r = st.number_input("Cantidad",1,1000,50)
            if st.form_submit_button("Reponer"):
                for m in st.session_state.inventario:
                    if m["nombre"]==item_r: m["stock"]+=cant_r; st.success(f"✅ Stock → {m['stock']}.")
                st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# 8. INSUMOS QUIRÚRGICOS  ← NUEVO
# ═══════════════════════════════════════════════════════════════════════════════
elif modulo == "🧰 Insumos Quirúrgicos":
    st.markdown("<h1>Insumos de Material Quirúrgico</h1>", unsafe_allow_html=True)
    st.markdown('<p style="color:#94a3b8;margin-bottom:20px">Hojas de bisturí · Spongostan · Suturas · Drenajes · Campo operatorio y más</p>', unsafe_allow_html=True)

    bajo_qx = [m for m in st.session_state.insumos_qx if 0 < m["stock"] <= m["minimo"]]
    agot_qx = [m for m in st.session_state.insumos_qx if m["stock"]==0]
    c1,c2,c3 = st.columns(3)
    c1.metric("Total insumos QX", len(st.session_state.insumos_qx))
    c2.metric("Stock bajo",       len(bajo_qx), delta_color="inverse")
    c3.metric("Agotados",         len(agot_qx), delta_color="inverse")

    for m in agot_qx:
        st.markdown(f'<div class="info-box" style="border-color:#ef4444">🚫 <b>{m["nombre"]}</b> — Sin stock. Requiere reposición urgente.</div>', unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    categorias_qx = sorted(set(m["categoria"] for m in st.session_state.insumos_qx))
    cat_sel = st.selectbox("Filtrar por categoría", ["Todas"] + categorias_qx)
    lista = st.session_state.insumos_qx if cat_sel=="Todas" else [m for m in st.session_state.insumos_qx if m["categoria"]==cat_sel]

    sec(f"Inventario quirúrgico — {cat_sel}")
    rows = ""
    for m in lista:
        pct = min(100, int(m["stock"]/max(m["minimo"]*2,1)*100))
        color,label = ("#ef4444","Agotado") if m["stock"]==0 else \
                      (("#f59e0b","Stock bajo") if m["stock"]<=m["minimo"] else ("#22c55e","OK"))
        rows += f"""
        <div style="background:#1e293b;border:1px solid #334155;border-radius:10px;padding:14px 18px;margin-bottom:8px">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <div>
              <b>{m['nombre']}</b>
              <span style="background:#0d374260;color:#67e8f9;border:1px solid #164e6360;
                border-radius:6px;padding:2px 8px;font-size:.72rem;margin-left:8px">{m['categoria']}</span>
            </div>
            <div style="color:{color};font-weight:600">{m['stock']} {m['unidad']} — {label}</div>
          </div>
          <div style="background:#0f172a;border-radius:4px;height:6px;margin-top:8px">
            <div style="background:{color};width:{pct}%;height:6px;border-radius:4px"></div>
          </div>
          <div style="color:#94a3b8;font-size:.75rem;margin-top:4px">Mínimo: {m['minimo']} · {m['codigo']}</div>
        </div>"""
    st.markdown(rows, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    col_a, col_b = st.columns(2)
    with col_a:
        sec("Reponer insumo quirúrgico")
        with st.form("form_repo_qx", clear_on_submit=True):
            item_r = st.selectbox("Insumo", [m["nombre"] for m in st.session_state.insumos_qx])
            cant_r = st.number_input("Cantidad a agregar",1,500,10)
            if st.form_submit_button("Reponer"):
                for m in st.session_state.insumos_qx:
                    if m["nombre"]==item_r: m["stock"]+=cant_r; st.success(f"✅ Stock → {m['stock']}.")
                st.rerun()
    with col_b:
        sec("Agregar nuevo insumo")
        with st.form("form_nuevo_qx", clear_on_submit=True):
            nombre_qx = st.text_input("Nombre del insumo")
            c1,c2 = st.columns(2)
            cat_qx    = c1.selectbox("Categoría",["Corte","Hemostasia","Sutura","Drenaje",
                                                    "Campo operatorio","Electrocirugía","Sondaje","Laparoscopía","Otro"])
            unidad_qx = c2.selectbox("Unidad",["Unidades","Cajas","Sobres","Paquetes","Rollos"])
            c3,c4 = st.columns(2)
            stock_qx  = c3.number_input("Stock inicial",0,1000,0)
            minimo_qx = c4.number_input("Stock mínimo",1,200,10)
            if st.form_submit_button("Agregar") and nombre_qx:
                codigo_nuevo = f"QX-{len(st.session_state.insumos_qx)+1:03d}"
                st.session_state.insumos_qx.append({
                    "codigo":codigo_nuevo,"nombre":nombre_qx,"categoria":cat_qx,
                    "stock":stock_qx,"minimo":minimo_qx,"unidad":unidad_qx
                })
                st.success(f"✅ {codigo_nuevo} agregado.")
                st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# 9. CIRUGÍAS  ← NUEVO
# ═══════════════════════════════════════════════════════════════════════════════
elif modulo == "🏥 Cirugías":
    st.markdown("<h1>Gestión de Cirugías</h1>", unsafe_allow_html=True)
    st.markdown('<p style="color:#94a3b8;margin-bottom:20px">Programación · Asignación · Insumos quirúrgicos · Seguimiento</p>', unsafe_allow_html=True)

    # ── Sub-vista: selección de insumos para una cirugía ─────────────────────
    if st.session_state.cirugia_insumos_id is not None:
        cir_id = st.session_state.cirugia_insumos_id
        cir    = next((c for c in st.session_state.cirugias if c["id"]==cir_id), None)

        if st.button("← Volver al detalle de la cirugía"):
            st.session_state.cirugia_insumos_id = None
            st.rerun()

        st.markdown(f"<h2>🧰 Insumos — {cir['id']} {cir['tipo']}</h2>", unsafe_allow_html=True)
        st.markdown(f'<p style="color:#94a3b8">Paciente: <b>{cir["paciente"]}</b> | Doctor: <b>{cir["doctor"]}</b></p>', unsafe_allow_html=True)

        if cir["insumos_usados"]:
            sec("Insumos ya asignados")
            html_ins = ""
            for ins in cir["insumos_usados"]:
                html_ins += f"""
                <div style="background:#162032;border:1px solid #334155;border-radius:8px;
                            padding:10px 16px;margin-bottom:6px;display:flex;justify-content:space-between">
                  <div><b>{ins['nombre']}</b> <span style="color:#94a3b8">({ins['codigo']})</span></div>
                  <div style="color:#14b8a6;font-weight:600">{ins['cantidad']} {ins['unidad']}</div>
                </div>"""
            st.markdown(html_ins, unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)
        sec("Agregar insumo del inventario quirúrgico")
        cats_qx = sorted(set(m["categoria"] for m in st.session_state.insumos_qx))
        cat_f = st.selectbox("Filtrar categoría", ["Todas"]+cats_qx, key="cat_cir")
        lista_qx = st.session_state.insumos_qx if cat_f=="Todas" else [m for m in st.session_state.insumos_qx if m["categoria"]==cat_f]
        disponibles = [m for m in lista_qx if m["stock"]>0]

        with st.form("form_asignar_insumo", clear_on_submit=True):
            if disponibles:
                opciones = [f"{m['nombre']}  ({m['stock']} disp.)" for m in disponibles]
                sel      = st.selectbox("Insumo", opciones)
                sel_idx  = opciones.index(sel)
                insumo_s = disponibles[sel_idx]
                cantidad = st.number_input("Cantidad a usar", 1, insumo_s["stock"], 1)
                if st.form_submit_button("➕ Asignar a esta cirugía"):
                    for m in st.session_state.insumos_qx:
                        if m["codigo"]==insumo_s["codigo"]: m["stock"]-=cantidad
                    cir["insumos_usados"].append({
                        "codigo":insumo_s["codigo"],"nombre":insumo_s["nombre"],
                        "cantidad":cantidad,"unidad":insumo_s["unidad"]
                    })
                    st.success(f"✅ {cantidad} × {insumo_s['nombre']} asignados.")
                    st.rerun()
            else:
                st.warning("No hay insumos con stock en esta categoría.")
                st.form_submit_button("—", disabled=True)

    # ── Sub-vista: detalle de una cirugía ─────────────────────────────────────
    elif st.session_state.detalle_cirugia is not None:
        idx = st.session_state.detalle_cirugia
        cir = st.session_state.cirugias[idx]

        if st.button("← Volver a la lista"):
            st.session_state.detalle_cirugia = None
            st.rerun()

        st.markdown(f"<h2>Cirugía {cir['id']} — {cir['tipo']}</h2>", unsafe_allow_html=True)
        st.markdown('<div class="detail-panel">', unsafe_allow_html=True)
        c1,c2,c3 = st.columns(3)
        c1.markdown(f"**Paciente:** {cir['paciente']}")
        c1.markdown(f"**Doctor:** {cir['doctor']}")
        c2.markdown(f"**Tipo:** {cir['tipo']}")
        c2.markdown(f"**Sala:** {cir['sala']}")
        c3.markdown(f"**Fecha:** {cir['fecha']} {cir['hora']}")
        c3.markdown(f"**Estado:** {cir['estado']}")

        st.markdown("<br>", unsafe_allow_html=True)
        n_ins = len(cir["insumos_usados"])
        if st.button(f"🧰 Gestionar insumos quirúrgicos ({n_ins} asignado{'s' if n_ins!=1 else ''})", use_container_width=True):
            st.session_state.cirugia_insumos_id = cir["id"]
            st.rerun()

        st.markdown("---")
        with st.form(f"edit_cir_{idx}"):
            c1,c2 = st.columns(2)
            nuevo_estado = c1.selectbox("Estado", ESTADOS_CIRUGIA,
                                         index=ESTADOS_CIRUGIA.index(cir["estado"]) if cir["estado"] in ESTADOS_CIRUGIA else 0)
            nuevo_doctor = c2.selectbox("Doctor asignado",
                                         [p["nombre"] for p in st.session_state.personal
                                          if any(x in p["cargo"] for x in ["Médico","Ginecó"])])
            nuevo_sala   = st.selectbox("Sala",["Quirófano 1","Quirófano 2","Sala de partos","Sala de procedimientos"])
            nota_txt = st.text_area("Nota / reporte operatorio", height=90,
                                     placeholder="Hallazgos intraoperatorios, técnica utilizada, incidencias...")
            autor = st.selectbox("Médico que registra", NOMBRES_MEDICOS())
            if st.form_submit_button("💾 Guardar cambios"):
                cir["estado"] = nuevo_estado
                cir["doctor"] = nuevo_doctor
                cir["sala"]   = nuevo_sala
                agregar_nota(cir, nota_txt, autor)
                st.success("✅ Cirugía actualizada.")
                st.rerun()

        st.markdown("---")
        render_notas(cir.get("notas",[]))
        st.markdown('</div>', unsafe_allow_html=True)

    # ── Lista de cirugías ─────────────────────────────────────────────────────
    else:
        prog = sum(1 for c in st.session_state.cirugias if c["estado"]=="Programada")
        enc  = sum(1 for c in st.session_state.cirugias if c["estado"]=="En curso")
        fin  = sum(1 for c in st.session_state.cirugias if c["estado"]=="Finalizada")
        c1,c2,c3 = st.columns(3)
        c1.metric("Programadas",prog); c2.metric("En curso",enc); c3.metric("Finalizadas",fin)

        st.markdown("<br>", unsafe_allow_html=True)
        sec("Lista de cirugías — presiona ✏️ para ver detalle e insumos")
        for idx, cir in enumerate(st.session_state.cirugias):
            est_col = {"Programada":"blue","En curso":"green","Finalizada":"purple",
                       "Suspendida":"yellow","Cancelada":"red"}.get(cir["estado"],"blue")
            col_card, col_btn = st.columns([9,1])
            with col_card:
                n_ins = len(cir["insumos_usados"])
                st.markdown(f"""
                <div class="record-card">
                  <b>{cir['id']} — {cir['tipo']}</b> &nbsp;{badge(cir['estado'],est_col)}
                  <br><span style="color:#94a3b8;font-size:.85rem">
                    👤 {cir['paciente']} | 👨‍⚕️ {cir['doctor']} | 📅 {cir['fecha']} {cir['hora']}
                    | 🧰 {n_ins} insumo(s) asignado(s)
                  </span>
                </div>""", unsafe_allow_html=True)
            with col_btn:
                st.markdown("<br>", unsafe_allow_html=True)
                if st.button("✏️", key=f"cir_edit_{idx}"):
                    st.session_state.detalle_cirugia = idx
                    st.rerun()

        st.markdown("<br>", unsafe_allow_html=True)
        sec("Programar nueva cirugía")
        with st.form("form_cir", clear_on_submit=True):
            c1,c2 = st.columns(2)
            pac_cir  = c1.text_input("Nombre del paciente")
            tipo_cir = c2.selectbox("Tipo de cirugía",[
                "Apendicectomía","Cesárea","Colecistectomía","Hernioplastia","Laparotomía exploratoria",
                "Legrado uterino","Salpingectomía","Plastia de herida","Desbridamiento","Drenaje de absceso",
                "Biopsia quirúrgica","Vasectomía","Otro procedimiento"])
            c3,c4 = st.columns(2)
            doctor_cir = c3.selectbox("Doctor asignado",
                                       [p["nombre"] for p in st.session_state.personal
                                        if any(x in p["cargo"] for x in ["Médico","Ginecó"])])
            sala_cir   = c4.selectbox("Sala / Quirófano",["Quirófano 1","Quirófano 2","Sala de partos","Sala de procedimientos"])
            c5,c6 = st.columns(2)
            fecha_cir = c5.date_input("Fecha", min_value=date.today())
            hora_cir  = c6.selectbox("Hora",["06:00","07:00","08:00","10:00","12:00","14:00","16:00"])
            if st.form_submit_button("📋 Programar cirugía") and pac_cir:
                nuevo_id = f"CIR-{len(st.session_state.cirugias)+1:03d}"
                st.session_state.cirugias.append({
                    "id":nuevo_id,"paciente":pac_cir,"doctor":doctor_cir,"tipo":tipo_cir,
                    "fecha":fecha_cir,"hora":hora_cir,"sala":sala_cir,"estado":"Programada",
                    "notas":[],"insumos_usados":[]
                })
                st.success(f"✅ {nuevo_id} programada. Ábrela para asignar insumos.")
                st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# 10. TELEMEDICINA
# ═══════════════════════════════════════════════════════════════════════════════
elif modulo == "🌐 Telemedicina":
    st.markdown("<h1>Telemedicina</h1>", unsafe_allow_html=True)
    st.markdown('<p style="color:#94a3b8;margin-bottom:20px">Consultas especializadas virtuales</p>', unsafe_allow_html=True)

    sec("Consultas — presiona ✏️ para editar")
    for idx, tm in enumerate(st.session_state.telemedicina):
        col_b = "green" if tm["estado"]=="En curso" else "blue"
        col_card, col_btn = st.columns([9,1])
        with col_card:
            st.markdown(f"""
            <div class="record-card">
              <b>{tm['id']}</b> — {tm['paciente']} &nbsp;{badge(tm['estado'],col_b)}
              <br><span style="color:#14b8a6;font-size:.85rem">👨‍⚕️ {tm['especialista']}</span>
              <br><span style="color:#94a3b8;font-size:.82rem">🕐 {tm['fecha'].strftime('%d/%m/%Y %H:%M')}</span>
            </div>""", unsafe_allow_html=True)
        with col_btn:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("✏️", key=f"tm_edit_{idx}"):
                st.session_state[f"tm_open_{idx}"] = not st.session_state.get(f"tm_open_{idx}",False)
                st.rerun()
        if st.session_state.get(f"tm_open_{idx}",False):
            with st.form(f"edit_tm_{idx}"):
                nuevo_estado = st.selectbox("Estado", ESTADOS_TELEMEDICINA,
                    index=ESTADOS_TELEMEDICINA.index(tm["estado"]) if tm["estado"] in ESTADOS_TELEMEDICINA else 0)
                nota_txt = st.text_area("Nota de la consulta virtual", height=60)
                autor    = st.selectbox("Responsable", NOMBRES_MEDICOS())
                if st.form_submit_button("💾 Guardar"):
                    tm["estado"] = nuevo_estado
                    agregar_nota(tm, nota_txt, autor)
                    st.session_state[f"tm_open_{idx}"] = False
                    st.rerun()
            render_notas(tm.get("notas",[]))

    st.markdown("<br>", unsafe_allow_html=True)
    sec("Solicitar interconsulta virtual")
    with st.form("form_tele", clear_on_submit=True):
        c1,c2   = st.columns(2)
        pac_t   = c1.text_input("Paciente")
        espec_t = c2.selectbox("Especialidad",["Cardiología","Neurología","Dermatología",
            "Endocrinología","Oncología","Psiquiatría","Ortopedia","Oftalmología"])
        c3,c4   = st.columns(2)
        fecha_t = c3.date_input("Fecha", min_value=date.today())
        hora_t  = c4.selectbox("Hora",["08:00","09:00","10:00","11:00","14:00","15:00","16:00"])
        st.text_area("Motivo", height=70)
        if st.form_submit_button("Solicitar") and pac_t:
            nuevo_id = f"TM-{len(st.session_state.telemedicina)+1:03d}"
            st.session_state.telemedicina.append({
                "id":nuevo_id,"paciente":pac_t,
                "especialista":f"{espec_t} – Pendiente asignación",
                "fecha":datetime.combine(fecha_t,time(int(hora_t[:2]),0)),
                "estado":"Programada","notas":[]
            })
            st.success(f"✅ {nuevo_id} solicitada.")
            st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# 11. EPIDEMIOLOGÍA
# ═══════════════════════════════════════════════════════════════════════════════
elif modulo == "📊 Epidemiología":
    st.markdown("<h1>Salud Pública y Vigilancia Epidemiológica</h1>", unsafe_allow_html=True)
    sec("Alertas activas")
    for row in st.session_state.epidemiologia:
        if row["alerta"]:
            st.markdown(f'<div class="info-box" style="border-color:#ef4444">⚠️ <b>ALERTA: {row["enfermedad"]}</b> — {row["casos"]} casos en semana {row["semana"]}</div>', unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    sec("Registro de eventos")
    df_epi = pd.DataFrame(st.session_state.epidemiologia)
    df_epi["alerta"] = df_epi["alerta"].map({True:"⚠️ Sí",False:"✅ No"})
    st.dataframe(df_epi.rename(columns={"semana":"Semana","enfermedad":"Enfermedad","casos":"Casos","alerta":"Alerta"}),
                 use_container_width=True, hide_index=True)

    with st.form("form_epi", clear_on_submit=True):
        c1,c2,c3,c4 = st.columns(4)
        semana_e = c1.text_input("Semana", f"2026-W{datetime.now().isocalendar()[1]}")
        enf      = c2.selectbox("Enfermedad",["IRA","EDA","Dengue","Malaria","COVID-19","Hepatitis A","Varicela","Sarampión"])
        casos_e  = c3.number_input("Casos",1,500,1)
        alerta_e = c4.selectbox("Alerta",["No","Sí"])
        if st.form_submit_button("Reportar"):
            st.session_state.epidemiologia.append({"semana":semana_e,"enfermedad":enf,"casos":casos_e,"alerta":alerta_e=="Sí"})
            st.success("✅ Evento reportado.")
            st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# 12. PERSONAL
# ═══════════════════════════════════════════════════════════════════════════════
elif modulo == "👤 Personal":
    st.markdown("<h1>Talento Humano en Salud</h1>", unsafe_allow_html=True)
    c1,c2,c3 = st.columns(3)
    c1.metric("Total personal",  len(st.session_state.personal))
    c2.metric("Médicos activos", sum(1 for p in st.session_state.personal if "Médico" in p["cargo"]))
    c3.metric("Enfermeras/aux.", sum(1 for p in st.session_state.personal if "Enferm" in p["cargo"]))

    st.markdown("<br>", unsafe_allow_html=True)
    sec("Personal activo")
    df_per = pd.DataFrame(st.session_state.personal)
    st.dataframe(df_per.rename(columns={"nombre":"Nombre","cargo":"Cargo","turno":"Turno","estado":"Estado"}),
                 use_container_width=True, hide_index=True)

    sec("Registrar nuevo colaborador")
    with st.form("form_per", clear_on_submit=True):
        c1,c2 = st.columns(2)
        nombre_p = c1.text_input("Nombre")
        cargo_p  = c2.selectbox("Cargo",["Médico General","Médico Urgencias","Ginecóloga","Pediatra",
            "Enfermera Profesional","Auxiliar Enfermería","Bacteriólogo","Odontólogo",
            "Trabajador Social","Administrador","Admisión","Seguridad"])
        c3,c4    = st.columns(2)
        turno_p  = c3.selectbox("Turno",["Mañana","Tarde","Noche"])
        sub      = c4.form_submit_button("Registrar", use_container_width=True)
        if sub and nombre_p:
            st.session_state.personal.append({"nombre":nombre_p,"cargo":cargo_p,"turno":turno_p,"estado":"Activo"})
            st.success(f"✅ {nombre_p} registrado/a.")
            st.rerun()